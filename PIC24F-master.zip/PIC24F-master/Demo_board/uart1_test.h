//****************************************
// UART1_Test
// 2013.10.10
// Regis Hsu
//****************************************

#ifndef _UART1_TEST_
#define _UART1_TEST_

void UART1_Init(void);
void vTask_Uart1_Test(void *pvParameters );

#endif