//****************************************
// IR_Remote0038
// 2013.10.12
// Regis Hsu
//****************************************

#ifndef _IR_Remote_
#define _IR_Remote_

void IR_Remote_Init(void);
void vTask_IR_Remote(void *pvParameters );
void IR_Remote_Test(void);

#endif